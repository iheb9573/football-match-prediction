'use client'

import { useEffect, useState } from 'react'
import { Skeleton } from '@/components/ui/skeleton'
import { PredictionCard } from '@/components/prediction-card'
import { Button } from '@/components/ui/button'
import { RefreshCw, Filter } from 'lucide-react'

export default function PredictionsPage() {
  const [predictions, setPredictions] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedLeague, setSelectedLeague] = useState('all')

  const fetchPredictions = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/predictions')
      const data = await res.json()
      setPredictions(data)
    } catch (error) {
      console.error('Error fetching predictions:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchPredictions()
  }, [])

  const leagues = ['all', ...new Set(predictions.map(p => p.match.league))]
  const filteredPredictions = selectedLeague === 'all' 
    ? predictions 
    : predictions.filter(p => p.match.league === selectedLeague)

  return (
    <main className="max-w-7xl mx-auto px-6 py-12">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Prédictions de Matchs
          </h1>
          <p className="text-slate-400">
            Analyse probabiliste et expliquée des matchs à venir
          </p>
        </div>
        <Button 
          onClick={fetchPredictions}
          className="gap-2 bg-blue-600 hover:bg-blue-700"
        >
          <RefreshCw size={18} />
          Actualiser
        </Button>
      </div>

      {/* Filters */}
      <div className="mb-8 flex items-center gap-4">
        <Filter size={18} className="text-slate-400" />
        <div className="flex gap-2 flex-wrap">
          {leagues.map((league) => (
            <Button
              key={league}
              variant={selectedLeague === league ? 'default' : 'outline'}
              onClick={() => setSelectedLeague(league)}
              className={selectedLeague === league ? 'bg-blue-600' : 'border-slate-700'}
            >
              {league === 'all' ? 'Toutes les ligues' : league}
            </Button>
          ))}
        </div>
      </div>

      {/* Predictions Grid */}
      {loading ? (
        <div className="grid md:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-80 bg-slate-800" />
          ))}
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-6">
          {filteredPredictions.length > 0 ? (
            filteredPredictions.map((pred) => (
              <PredictionCard key={pred.id} {...pred} />
            ))
          ) : (
            <div className="col-span-2 text-center py-12 text-slate-400">
              Aucune prédiction disponible pour cette ligue
            </div>
          )}
        </div>
      )}
    </main>
  )
}
