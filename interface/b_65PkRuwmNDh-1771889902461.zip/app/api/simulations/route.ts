import { NextResponse } from 'next/server'

export async function GET() {
  const simulations = {
    championshipWinners: [
      { team: 'Manchester City', probability: 0.28, simulations: 280000 },
      { team: 'Real Madrid', probability: 0.18, simulations: 180000 },
      { team: 'Bayern Munich', probability: 0.15, simulations: 150000 },
      { team: 'PSG', probability: 0.12, simulations: 120000 },
      { team: 'Arsenal', probability: 0.10, simulations: 100000 },
      { team: 'Barcelona', probability: 0.08, simulations: 80000 },
      { team: 'Others', probability: 0.09, simulations: 90000 }
    ],
    topFourProbabilities: [
      { team: 'Manchester City', topFour: 0.89 },
      { team: 'Real Madrid', topFour: 0.82 },
      { team: 'Bayern Munich', topFour: 0.78 },
      { team: 'PSG', topFour: 0.75 },
      { team: 'Arsenal', topFour: 0.72 },
      { team: 'Barcelona', topFour: 0.68 }
    ],
    seasonTrends: [
      { week: 1, leader: 'Manchester City', leadProb: 0.22 },
      { week: 5, leader: 'Manchester City', leadProb: 0.25 },
      { week: 10, leader: 'Arsenal', leadProb: 0.24 },
      { week: 15, leader: 'Manchester City', leadProb: 0.26 },
      { week: 20, leader: 'Manchester City', leadProb: 0.28 },
      { week: 25, leader: 'Real Madrid', leadProb: 0.27 },
      { week: 30, leader: 'Manchester City', leadProb: 0.29 },
      { week: 34, leader: 'Manchester City', leadProb: 0.30 }
    ]
  }

  return NextResponse.json(simulations)
}
