import { NextResponse } from 'next/server'

// Mock data for football predictions
export async function GET() {
  const predictions = [
    {
      id: 1,
      match: {
        date: '2024-02-24T15:00:00Z',
        homeTeam: 'Paris Saint-Germain',
        awayTeam: 'Lyon',
        league: 'Ligue 1',
        stadium: 'Parc des Princes'
      },
      probabilities: {
        home: 0.58,
        draw: 0.26,
        away: 0.16
      },
      prediction: 'H',
      confidence: 0.85,
      xG_home: 2.1,
      xG_away: 0.8,
      features: {
        homeFormRating: 4.2,
        awayFormRating: 2.8,
        homeAttack: 8.5,
        homeDefense: 7.2,
        awayAttack: 6.1,
        awayDefense: 6.8,
        headToHead: 'PSG leads 15-3'
      }
    },
    {
      id: 2,
      match: {
        date: '2024-02-24T18:00:00Z',
        homeTeam: 'Manchester City',
        awayTeam: 'Arsenal',
        league: 'Premier League',
        stadium: 'Etihad Stadium'
      },
      probabilities: {
        home: 0.52,
        draw: 0.28,
        away: 0.20
      },
      prediction: 'H',
      confidence: 0.72,
      xG_home: 1.9,
      xG_away: 1.2,
      features: {
        homeFormRating: 4.5,
        awayFormRating: 4.0,
        homeAttack: 8.8,
        homeDefense: 8.1,
        awayAttack: 8.2,
        awayDefense: 7.5,
        headToHead: 'Recent matches very close'
      }
    },
    {
      id: 3,
      match: {
        date: '2024-02-24T20:00:00Z',
        homeTeam: 'Real Madrid',
        awayTeam: 'Barcelona',
        league: 'La Liga',
        stadium: 'Santiago Bernabéu'
      },
      probabilities: {
        home: 0.55,
        draw: 0.25,
        away: 0.20
      },
      prediction: 'H',
      confidence: 0.78,
      xG_home: 2.3,
      xG_away: 1.1,
      features: {
        homeFormRating: 4.3,
        awayFormRating: 3.9,
        homeAttack: 8.6,
        homeDefense: 7.8,
        awayAttack: 8.1,
        awayDefense: 7.2,
        headToHead: 'Real leads historically'
      }
    },
    {
      id: 4,
      match: {
        date: '2024-02-25T15:00:00Z',
        homeTeam: 'Bayern Munich',
        awayTeam: 'Borussia Dortmund',
        league: 'Bundesliga',
        stadium: 'Allianz Arena'
      },
      probabilities: {
        home: 0.62,
        draw: 0.22,
        away: 0.16
      },
      prediction: 'H',
      confidence: 0.89,
      xG_home: 2.5,
      xG_away: 0.9,
      features: {
        homeFormRating: 4.6,
        awayFormRating: 3.5,
        homeAttack: 8.9,
        homeDefense: 8.3,
        awayAttack: 7.8,
        awayDefense: 7.0,
        headToHead: 'Bayern dominates'
      }
    }
  ]

  return NextResponse.json(predictions)
}
